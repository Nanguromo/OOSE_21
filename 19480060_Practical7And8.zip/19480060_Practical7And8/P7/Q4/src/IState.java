public interface IState
{
    /*public void pressurise();
    public void depressurise();*/
    public void openInnerDoor();
    public void openOuterDoor();
    //public void updatePressure(double pressure);
}
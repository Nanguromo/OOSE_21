Image Viewer -- Java, JavaFX
============================

This is an (unfinished) Java-based image viewer, using the JavaFX. JavaFX is
a GUI framework that supersedes Swing, but is usually a separate package from 
the JDK itself.

To compile and run (in a single step), simply run:
On Linux/MacOS: './gradlew'
On Windows:     'gradlew'

Note: if you have Java 11, the build script will download and setup JavaFX 
automatically. Otherwise, you must already have JavaFX installed for whatever
current version of Java you're using.

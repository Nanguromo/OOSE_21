public interface ImageData
{
    public String getMetadata();

    public void setMetaData();

    public String getFilename();

    public String getCaption();

    public String getGPS();

    public String getRating();

    public String getDate();
}
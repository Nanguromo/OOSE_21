#include <stdio.h>
#include <ctype.h> /*contains isdigit(); usesd for validation of input*/
#include "Settings.h" /*contains TRUE, FALSE definition*/
#include <string.h>
#include <stdlib.h>
#include "GameLogic.h"
#include "Logging.h"
#include "LinkedList.h"

/********************************
 *FUNCTION: displayOption
 *IMPORT: none
 *EXPORT: none
 *ASSERTION:
 *PURPOSE: Displays menu to user on terminal
 *********************************/
void displayOptions()
{
    printf("|=======================================|\n");
    printf("|           TicTacToe                   |\n");
    printf("|=======================================|\n");
    printf("|                                       |\n");
    printf("|   1: Start a new game                 |\n");
    printf("|   2: View the settings of the game    |\n");
    printf("|   3: View the current logs            |\n");  
    #ifndef SECRET
    #ifndef EDITOR 
    printf("|   4: Save the logs to a file          |\n");
    printf("|   5: Exit                             |\n");
    printf("|                                       |\n");
    printf("|=======================================|\n");
    printf("\nSelect one of the above options: ");
    #endif
    #endif

    #ifndef SECRET
    #ifdef EDITOR 
    printf("|   4: Save the logs to a file          |\n");
    printf("|   5: Change Settings                  |\n");
    printf("|   6: Exit                             |\n");
    printf("|                                       |\n");
    printf("|=======================================|\n");
    printf("\nSelect one of the above options: ");
    #endif
    #endif

    #ifdef SECRET
    #ifdef EDITOR
    printf("|   4: Change Settings                  |\n");
    printf("|   5: Exit                             |\n");
    printf("|                                       |\n");
    printf("|=======================================|\n");
    printf("\nSelect one of the above options: ");
    #endif
    #endif
   
    #ifdef SECRET
    #ifndef EDITOR 
    printf("|   4: Exit                             |\n");
    printf("|                                       |\n");
    printf("|=======================================|\n");
    printf("\nSelect one of the above options: ");
    #endif
    #endif

    /*#ifdef EDITOR
    
    printf("|   5: Change Settings                  |\n");
    printf("|   6: Exit                             |\n");
    printf("|                                       |\n");
    printf("|=======================================|\n");
    #else*/
}   

/*************************
 * FUNCTION: getOption
 * IMPORT: none
 * EXPORT: int parsedOption 
 * ASSERTION: parsedOption will be one of the menu options
 * PURPOSE: To get a valid integer input within the bounds of the menu from the user
 ************************/
int getOption()
{
    /*malloc char* to so it can be used to handle non integer input*/
    /*size 100 is arbitrary and is later freed to avoid memory issues*/
    char* option = (char*)malloc(100*sizeof(char));
    int i, parsedOption;
    int valid = TRUE;
    
    /*scan in option as a string so we can parse it later into an int and check if the user actually entered in an int with the isdigit() function*/
    scanf("%s", option);

    i = 0;
    while(option[i] != '\0')
    {
        if(!isdigit(option[i]))/*use to check every character of the string is an int. As soon as a char is found, valid is false, which indicates an invalid input*/
        {
            valid = FALSE;
        }
        i++;
    }

    if(valid == TRUE)/*if an int was entered, check that it is within valid bounds*/
    {
        parsedOption = atoi(option);/*parse string into an int we can check bounds*/
       
        #ifdef EDITOR
        #ifndef SECRET 
        if(parsedOption <= 0 || parsedOption > 6)
        {
            printf("Error: choice must be between 1 and 6, inclusive!\n");
            parsedOption = 0;/*Set as 0 if invalid, so it can be returned to indicate an error in the main function that caled this function*/
        }
        #else
        if(parsedOption <= 0 || parsedOption > 5)
        {
            printf("Error: choice must be between 1 and 5, inclusive!\n");
            parsedOption = 0;/*Set as 0 if invalid, so it can be returned to indicate an error in the main function that caled this function*/
        }
        #endif
        #else
        #ifndef SECRET
        if(parsedOption <= 0 || parsedOption > 5)
        {
            printf("Error: choice must be between 1 and 5, inclusive!\n");
            parsedOption = 0;/*Set as 0 if invalid, so it can be returned to indicate an error in the main function that caled this function*/
        }
        #else
        if(parsedOption <= 0 || parsedOption > 4)
        {
            printf("Error: choice must be between 1 and 4, inclusive!\n");
            parsedOption = 0;/*Set as 0 if invalid, so it can be returned to indicate an error in the main function that caled this function*/
        }
        #endif
        #endif
    }
    else
    {
        if(atoi(option) < 0)/*Do this because when checking for if a number is an int, a negative symbol will be treated as a character*/
        {
            printf("Error: choice cannot be negative!\n");
        }
        else
        {
            printf("Error: choice must be an integer!\n");
        }
        parsedOption = 0;/* " "*/
    }
    free(option);/*free the malloc'd char**/
    option = NULL;/*avoid using pointer agian*/
    
    return parsedOption;/*This return value will be checked to see what option to execute or to quit the program if an error was found ( return parsedOption = 0)*/
}

/*************************
 * FUNCTION: drawEmptyBoard
 * IMPORT: int m, int n
 * EXPORT: none
 * ASSERTION: draws an m x n board
 * PURPOSE: displays the initial empty board for the user to play with
 ************************/
void drawEmptyBoard(int m, int n)
{
    int i, j, k;
    i = 0;
    j = 0;
           
    printf("\n==");
    while(i < m)
    {
        printf("====");
        i++;
    }
    printf("==\n");

    for(i = 0; i < n; i++)
    {
        for(j = 0; j < m; j++)
        {
            if(j == 0)
            {
                printf("||   |");
            }
            else if(j == m - 1)
            {
                printf("   ||");
            }
            else
            {
                if(j != m-1)
                {
                    printf("   |");
                }
            }
        }
        printf("\n");
        k= 0;
        printf("==");
        while(k < m)
        {
            printf("====");
            k++;
        }
        printf("==\n");
    }
    printf("\nPlayer 1 is noughts (O). Player 2 is crosses (X).\n");
    printf("Player 1 goes first.\n");
}

/*************************
 * FUNCTION: drawGame 
 * IMPORT: int m, int n, int k, int nGamePlayed, LinkedList* ll, char* logfile
 * EXPORT: none
 * ASSERTION: a game will be played with a resulting winner or draw
 * PURPOSE: To display the game for the user as they enter their move and determine winner/draw
 ************************/
void drawGame(int m, int n, int k, int nGamePlayed, LinkedList* ll, char* logfile)
{
    int turn, x, y, i, j, z, gameCtr, errorCtr;
    char* errorMsg = "Invalid input: x and/or y input cannot be greater than the width and/or height or the board!\n";
    int gameWinner = FALSE; 
    Tile** grid = NULL;
    grid = (Tile**)malloc(n*sizeof(Tile*));/*pointer to an array of char pointers*/
    i = 0;
    j = 0;
    z = 0;
    for(i = 0; i < n; i++)
    {
        *(grid+i) =  NULL;
        *(grid+i) = (Tile*)malloc(m*sizeof(Tile));/*each row pointers to an array of chars, m wide*/
    }

    for(i = 0; i < m; i ++)
    {
        for(j = 0; j < n; j++)
        {
            (*(*(grid+j)+i)).isEmpty = TRUE;
            (*(*(grid+j)+i)).type = z++;/*initialise as an abritary character that is not O or X*/
            /*(*(*(grid+j)+i)).move = (Move*)malloc(sizeof(Move));*/
        }
    }
    z=0;
    gameCtr = 0;
    errorCtr = 0;
    turn = 1;/*Player one always starts first*/
 
  
    do
    {
        if(turn == 1)
        {
            do
            {
                if(errorCtr == 0)
                {   
                    printf("Player 1, enter your move (x,y): ");
                    scanf("%d, %d", &x, &y);
                }
                else
                {
                    if(checkBounds(m, n, x, y) == FALSE)
                    {
                        printf("%sPlayer 1, enter your move (x,y): ", errorMsg);
                        scanf("%d, %d", &x, &y);
                    }
                    else
                    {
                        printf("Invalid input: Tile is not free!\nPlayer 1 please choose another tile (x,y): ");
                        scanf("%d, %d", &x, &y);
                    }
                }
                errorCtr++;
            }while(checkBounds(m, n, x, y) == FALSE || checkFreeTile(x, y, grid) == FALSE);

            (*(*(grid+y)+x)).type = 'O';
            (*(*(grid+y)+x)).isEmpty = FALSE;
                
            (*(*(grid+y)+x)).move.x = x;/*used for game log history*/
            (*(*(grid+y)+x)).move.y = y;/*used for game log history*/
            (*(*(grid+y)+x)).turn = gameCtr + 1; /*track what turn the move was for the linked list log*/
            
            insertLast(ll, *(grid+y)+x);
            
            gameWinner = checkWinningMove(grid, x, y, m, n, k);                 
            turn = 2;
            errorCtr = 0;
        }   
        else
        {
            
            do
            {   
                if(errorCtr == 0)
                {   
                    printf("Player 2, enter your move (x,y): ");
                    scanf("%d, %d", &x, &y);
                }
                else
                {
                    if(checkBounds(m, n, x, y) == FALSE)
                    {
                        printf("%sPlayer 2, enter your move (x,y): ", errorMsg);
                        scanf("%d, %d", &x, &y);
                    }
                    else
                    {
                        printf("Invalid input: Tile is not free!\nPlayer 2 please choose another tile (x,y): ");
                        scanf("%d, %d", &x, &y);
                    }
                }
                errorCtr++;
            }while(checkBounds(m, n, x, y) == FALSE || checkFreeTile(x, y, grid) == FALSE);
            
            (*(*(grid+y)+x)).type = 'X';
            (*(*(grid+y)+x)).isEmpty = FALSE;

            (*(*(grid+y)+x)).move.x = x;/*used for game log move history*/
            (*(*(grid+y)+x)).move.y = y; /*used for game log move history*/
            (*(*(grid+y)+x)).turn = gameCtr + 1; /*track what turn the move was for the linked list logging*/
           
            insertLast(ll, *(grid+y)+x);
            
            gameWinner = checkWinningMove(grid, x, y, m, n, k);                 
            
            turn = 1;
            errorCtr = 0;
        }

        i = 0;
        printf("\n==");
        while(i < m)
        {
            printf("====");
            i++;
        }
        printf("==\n");

        for(i = 0; i < n; i++)
        {
            for(j = 0; j < m; j++)
            {
                if(j == 0)
                {
                    if( (*(*(grid+i)+j)).isEmpty == FALSE )
                    {
                        printf("|| %c |", (*(*(grid+i)+j)).type);
                    }
                    else
                    {
                        printf("||   |");
                    }
                }
                else if(j == m - 1)
                {
                    if((*(*(grid+i)+j)).isEmpty == FALSE)
                    {
                        printf(" %c ||", (*(*(grid+i)+j)).type );
                    }
                    else
                    {
                        printf("   ||");
                    }
                }
                else
                {
                    if((*(*(grid+i)+j)).isEmpty == FALSE )
                    {
                        printf(" %c |", (*(*(grid+i)+j)).type );
                    }
                    else
                    {
                        printf("   |");
                    }
                }
            }   
            printf("\n");
            /*z is used to print the top and bottom bounds of the grip*/
            z = 0;
            printf("==");
            while(z < m)
            {
                printf("====");
                z++;
            }
            printf("==\n");
        }
        gameCtr++;/*gameCtr tracks the number of moves. There are m*n moves max per game*/
    }while( (gameCtr < m*n) && (gameWinner != TRUE) );/*stop as soon as one of the conditions are false*/
   
    if(gameCtr == m*n && gameWinner != TRUE)
    {
        printf("\nThe game was a draw!\n");
    }
    else
    {
        if(grid[y][x].type == 'O')
        {
            printf("\nPlayer 1 (O) has won!\n");
        }
        else
        {
            printf("\nPlayer 2 (X) has won!\n");
        }
    }
    
    /*for(i = 0; i < n; i++)
    {
        free( *(grid+i) );
    }*/
 
    /*for(i = 0; i < m; i ++)
    {
        for(j = 0; j < n; j++)
        {
            if( (*(*(grid+j)+i)).isEmpty == TRUE)
            {
               free( (*(grid+j)+i) );
            }
        }
    }*/

    /*free(grid);*/
}

/*************************
 * FUNCTION: getNewSettings 
 * IMPORT: Settings* s
 * EXPORT: none
 * ASSERTION: Changes the game settings
 * PURPOSE: Display and get new settings from the user 
 ************************/
void getNewSettings(Settings* s)
{
    int errorCtr = 0; 
    do
    {
        if(errorCtr == 0)
        {
            printf("Enter new width, M: ");
            scanf("%d", &(s->opt[0].val));

            printf("Enter new heigh, N: ");
            scanf("%d", &(s->opt[1].val));

            printf("Enter new number of consecutive tiles to win, K: ");
            scanf("%d", &(s->opt[2].val));
            errorCtr++;
        }
        else
        {
            printf("\nError: Settings must an integer greater than zero AND K must cannot be bigger than larger value of M (width) or N (height)!\n");
            
            printf("Enter new width, M: ");
            scanf("%d", &(s->opt[0].val));

            printf("Enter new heigh, N: ");
            scanf("%d", &(s->opt[1].val));

            printf("Enter new number of consecutive tiles to win, K: ");
            scanf("%d", &(s->opt[2].val));
        }
    }while(s->opt[0].val <= 0 || s->opt[1].val <= 0 || s->opt[2].val <= 0 || checkValidTiles(s->opt[0].val, s->opt[1].val, s->opt[2].val) == FALSE);
}   

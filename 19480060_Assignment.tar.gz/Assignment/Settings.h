#ifndef SETTINGS
#define SETTINGS

/*Name: Option
 *Purpose: Stores the read setting on each line of the settings file read
 *Functionality: Assign name and value from file to the field's of Option to hold a setting, i.e. width and its value
 *Relation: An array of Options are made to hold the file settings of the game, i.e. Width, Height and number of tiles in a row to win the game*/
typedef struct{
    char name;
    int val;
}Option;

/*Name: Settings
 *Purpose: A struct used to hold the game settings read in by the file IO
 *Functionality: The settings file read will have every line assigned to an index in the Option array to create the game settings
 *Relation: An array of Option structs compile its field*/
typedef struct{
    Option opt[3];
}Settings;

/*Name: TRUE and FALSE
 *Purpose: Used as a 'makeshift' boolean for validation settings read in by file IO
 *Functionality: 1 is true and 0 is false. Use it in an if statement to ensure valid settings were read
 *Relation: Used in validation functions throughout the Settings.c*/
#define TRUE 1
#define FALSE 0

int readSettings(Settings* s, char* file);

int checkSettingVal(char c, int val);

int findDuplicates(Settings* s);

int checkRequiredSettings(int ctr);

int checkValidTiles(int m, int n, int k);

void changeSettings(Settings* s);

void displaySettings(Settings* s);

int find(char c, Settings* s);
#endif

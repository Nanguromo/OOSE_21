Program: TicTacToe
Author: Wayne Nanguromo
Purpose: Practice understanding what the consumer wants as well as designing, impementing, and testing a project.           Furthermore, gives insight in software development lifecycle as well. 
Date: 20/10/2019
Last Edited: 20/10/2019 - 5:06PM
-----------------------------------------------------------------------------------------------------------------

EXTRA FEATUERES: 
    - Can handle invalid inputs that are non-integer, i.e double, chars or string for the option input
    - 

FILES:  
    - TicTacToe.c (MAIN)
    - Settings.c + Settings.h
    - UserInterFace.c + UserInterface.h
    - GameLogic.c + GameLogic.h
    - Logging.c + Logging.h
    - LinkedList.c + LinkedList.h
    - Makefile

TEST FILES: 
    - SettingsTest1.txt
    -

-----------------------------------------------------------------------------------------------------------------
FUNCTIONALITY
-----------------------------------------------------------------------------------------------------------------
COMPILATION: 
    -NORMAL COMPILATION:
        run makefile with 'make' command to compile TicTaCToe
    
    -SECRET COMPILATION:
        run makefile with 'make SECRET=1' command to compile 'secret' mode TicTacToe
    
    -EDITOR COMPILATION
        run makefile with 'make EDITOR=1' command to compile 'editor' mode TicTaacToe

EXECUTION: To execute, run the executable with the TicTacToe game settings text file(.txt) as a command line argument.
        
            i.e should match follow the format (except without the < >):
                    ./TicTacToe <SettingsFile.txt>

ENTERING A MOVE:
        - Your input should be two integers without the bounds of M and N
        - The input should be entered in the for x,y
            -e.g Entering 3,4 would make you go 3 across and 4 down.
            -e.g Entering 0,0 would be the first block (origin).
            -e.g Entering 5,2 would make you go 5 across and 2 down.

TESTING:
    -Used 'SettingTest1.txt' to run tests:
        - changed the values of M, N and K to check file IO
        - played the game with multiple settings to ensure win condition works
    -Visual indication that printing and saving logs work by opening the created log file and seeing the terminal       ouput

-----------------------------------------------------------------------------------------------------------------
TO-DO
-----------------------------------------------------------------------------------------------------------------
MEMORY ERRORS: 
    - valgrind showing freeing the same thing twice, although, the program is fully functional
        - valgrind shows there are no debilitating memory leaks 


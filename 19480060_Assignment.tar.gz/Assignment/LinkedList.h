#ifndef LINKED_LIST
#define LINKED_LIST
    typedef struct LinkedListNode{
        void* data; /*points to some arbitrary value of any data type*/
        struct LinkedListNode* next;/*points to next node or null if it's the last*/
        struct LinkedListNode* prev;
    }LinkedListNode;

    typedef struct{
        int size;
        LinkedListNode* head;
        LinkedListNode* tail;
    }LinkedList;

    typedef void (*FUNC_PTR)(void* anything);

    LinkedList* createLinkedList();

    void insertStart(LinkedList* list, void* entry);

    void* removeStart(LinkedList* list);

    void insertLast(LinkedList* list, void* entry);

    void* removeLast(LinkedList* list);

    void printLinkedList(LinkedList* list, FUNC_PTR func);

    void freeLinkedList(LinkedList* list, FUNC_PTR func);

    void freeTile(void* tile);

    void printTile(void* data);
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "GameLogic.h"

/***************************
 *FUNCTION createLinkedList:
 *IMPORT: none
 *EXPORT: LinkedList* ll
 *ASSERTION: returns an empty linked list
 *PURPOSE: create LinkedList struct which holds the head, tail and size
 ***************************/
LinkedList* createLinkedList()
{
    /*No elements added yet, hence, head and tail will point to null*/
    LinkedList* ll = (LinkedList*)malloc(sizeof(LinkedList));
    ll->size = 0;
    ll->head = NULL;
    ll->tail = NULL;
    
    return ll;     
}

/***************************
 *FUNCTION insertStart
 *IMPORT: LinkedList* ll, void* entry
 *EXPORT: none
 *ASSERTION: LinkedList size increases by 1 
 *PURPOSE: inserts data at the start of the linked list
 ***************************/
void insertStart(LinkedList* ll, void* entry)
{
    LinkedListNode* node = (LinkedListNode*)malloc(sizeof(LinkedListNode));
    (*node).data = (void*)entry;
    ll->size = ll->size + 1;

    if(ll->head == NULL) /*Linked list is empty. Don't have to consider tail, would be the same case*/
    {
        ll->head = node;/* both head and tail point to same node, i.e first node*/
        ll->tail = node;
        node->prev = NULL;/*node points to null for tail and head because it is the first inserted node*/
        node->next = NULL;
    }        
    else
    {
        ll->head->prev = node;/*old first node previous points to new node*/
        node->next = ll->head; /* new node points to what head is pointing to*/
        ll->head = node;/*head now points to new node which points to previous former head.*/
        
        /*don't do anything to tail as it is still pointing to the last node*/              
        node->prev = NULL;/*previous points to NULL*/       
    }
}            

/***************************
 *FUNCTION removeLast
 *IMPORT: LinkedList* ll
 *EXPORT: void* j (data)
 *ASSERTION: LinkedList size decreases by 1 
 *PURPOSE: removes data at the start of the linked list
 ***************************/
void* removeStart(LinkedList* ll)
{
    LinkedListNode* temp; /*(LinkedListNode*)malloc(sizeof(LinkedListNode));*/
    /*Make a copy of data in first node of linked list for returning*/
    /*void* j = (void*)malloc(sizeof(void));*/
    void* j = (void*)ll->head->data;/*cast struct data to void* */
    ll->size = ll->size - 1;

    temp = ll->head;/*make a copy of head pointer*/
    ll->head = ll->head->next;/*set head pointer to second element*/
    ll->head->prev = NULL;
    /*free(temp->data); Don't free data as it was NOT malloc'd*/
    free(temp);/*free first node*/
    
    
    return j;    
}

/***************************
 *FUNCTION insertLast
 *IMPORT: LinkedList* ll, void* entry
 *EXPORT: none
 *ASSERTION: LinkedList size increases by 1 
 *PURPOSE: inserts data at the end of the linked list
 ***************************/
void insertLast(LinkedList* ll, void* entry)
{
    LinkedListNode* node = (LinkedListNode*)malloc(sizeof(LinkedListNode));
    node->data = (void*)entry;
    ll->size = ll->size +1;

    if(ll->head == NULL)/*Linked list is empty.*/
    {   
        ll->head = node;
        ll->tail = node;
        node->prev = NULL;
        node->next = NULL;
    }
    else
    {
        node->prev = ll->tail; /*new node prev points to what tail is pointing to*/
        node->next = NULL;/*last node points to null*/
        ll->tail->next = node;/*former last node now points to new last node*/
        ll->tail = node;/*tail now points to new last node*/
        
        /*Don't need to do anything with the head as it stays the same*/
    }
}

/***************************
 *FUNCTION: removeLast
 *IMPORT: LinkedList* ll
 *EXPORT: void* j (data)
 *ASSERTION: LinkedList size decreases by 1 
 *PURPOSE: remove data at the end of the linked list
 ***************************/
void* removeLast(LinkedList* ll)
{
    LinkedListNode* temp;/*(LinkedListNode*)malloc(sizeof(LinkedListNode));*/ 
    /*Make a copy of data in the last node of linked list for returning*/
    void* j = (void*)ll->tail->data;
    ll->size = ll->size - 1;

    temp = ll->tail;/*make a copy of tail pointer*/
    ll->tail = ll->tail->prev;/*set tail pointer to second last element*/
    ll->tail->next = NULL;
    /*free(temp->data);*Don't have to free value of data as it was NOT malloc'd*/
    free(temp);/*Free last node*/

    return j;
}

/***************************
 *FUNCTION: printLinkedList
 *IMPORT: LinkedList* ll, FUNC_PTR func
 *EXPORT: none
 *ASSERTION: Takes a function pointer to print the data type of the held data
 *PURPOSE: Prints out entire linked list 
 ***************************/
void printLinkedList(LinkedList* ll, FUNC_PTR func)
{
    LinkedListNode* tempNode = ll->head;
   
    while(tempNode != NULL)
    {
        func(tempNode->data);
        tempNode = tempNode->next;
    }   
}

/***************************
 *FUNCTION: freeLinkedList
 *IMPORT: LinkedList* ll, FUNC_PTR func
 *EXPORT: none
 *ASSERTION: Takes a function pointer to print the data type of the held data
 *PURPOSE: Frees entire linked list
 ***************************/
void freeLinkedList(LinkedList* ll, FUNC_PTR func)
{
    LinkedListNode* currNode;
    LinkedListNode* node;
 
    /*printf("Linked List size: %d", ll->size);*/
    currNode = ll->head;
    while(currNode != NULL)
    {       
        node = currNode;
        currNode = currNode->next;
        func(node->data);
        free(node);/*Free the node, itself*/
        /*node = NULL;     */
    }

    free(ll);/*Finally, free the linked list struct as all of its contents have been freed*/
        /*free((Journal*)data);if data is stored, it will be freed*/
    ll = NULL;
}


/***************************
 *FUNCTION: printTile
 *IMPORT: void* tile
 *EXPORT: none
 *ASSERTION: Typecasts void* to Tile* so data can be printed
 *PURPOSE: prints out the field of the Tile* struct pointer
 ***************************/
void printTile(void* tile)
{
    Tile* t = (Tile*)tile; 
    printf("%c -> (x,y) = (%d, %d)\n", t->type, t->move.x, t->move.y);
}

/***************************
 *FUNCTION: freeTile
 *IMPORT: void* tile
 *EXPORT: none
 *ASSERTION: Tylecasts void* to Tile* so data can be freed
 *PURPOSE: frees the Tile* struct pointer
 ***************************/
void freeTile(void* tile)
{
    Tile* t = (Tile*)tile;

    /*(free(t->move);*/
    free(t);
}


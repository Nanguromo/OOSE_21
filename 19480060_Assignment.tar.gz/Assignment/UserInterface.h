#include "LinkedList.h"
#include "Settings.h"
#ifndef USER_INTERFACE
#define USER_INTERFACE
    void displayOptions();

    int getOption();
   
    void drawEmptyBoard(int m, int n); 

    void drawGame(int m, int n, int k, int gameCtr, LinkedList* ll, char* logfile);

    void getNewSettings(Settings* s);
#endif

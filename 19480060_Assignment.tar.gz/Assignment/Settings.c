#include <stdio.h>
#include "Settings.h"
#include "UserInterface.h"

/**************************
 *FUNCTION: readSettings  
 *IMPORT: Settings* s, char* fileName
 *EXPORT: int hadError (BOOLEAN)
 *ASSERTION: hadError will be either TRUE (1) or FALSE (0)
 *PURPOSE: Read initial settings from file and tell the main function to continue if the read settings are valid
****************************/
int readSettings(Settings* s, char* fileName)
{
    FILE *file = fopen(fileName, "r");/*try to open file for reading*/
    int nRead = 2;/*Used to ensure number of read variables is correct to ensure settings file */
    char cursor[4];/*Used to move cursor to next line*/
    int hadError = FALSE;/*This is returned to main. If it is true, the program should exit.*/
    int ctr = 0; /*Used to check if 3 settings were read successfully*/
    int i;
    int ctr2 = 0;/*Used to track what error to print out for invalid value*/
   
    /*these temp variables are used to make the order the settings read irrelevant*/ 
    int tempM_val = 0;
    int tempN_val = 0;
    int tempK_val = 0;

    if(file != NULL) /*Check if file sas opened successfully*/
    {
        /*NOTE: We know the number of lines in the settings file (3). Hence, we can manually do 3 reads*/
        for(i = 0; i < 3; i++)
        {
            nRead = fscanf(file, "%c=%d", &s->opt[i].name, &s->opt[i].val);
            fgets(cursor, 4, file);/*move cursor to next line*/

            if(s->opt[i].name >= 'a' && s->opt[i].name <= 'z')
            {
                s->opt[i].name = (int)s->opt[i].name - 32;/*convert to uppercase to make case-insensitive*/
            }

            if(ferror(file))
            {
                perror("Error: from reading file!\n");
            }

            if(nRead == 2)/*ensure name and value were read*/
            {
                ctr++;
                if(checkSettingVal(s->opt[i].name, s->opt[i].val) == FALSE)
                {
                    hadError = TRUE;
                    switch(ctr2)
                    {
                        case 0: 
                            printf("Error: Invalid setting value for width!\n");
                            break;
                        case 1:
                            printf("Error: Invalid setting value for height!\n");
                            break;
                        case 2:
                            printf("Error: Invalid setting value for number of matching tiles to win!\n");
                            break;
                        default:    
                            break;
                    }   
                }
                ctr2++;
            } 
        }

        if(checkRequiredSettings(ctr) == FALSE)
        {
            printf("Error: Could not successfully read three required settings!\n"); 
            hadError = TRUE;
        }
                
        if(findDuplicates(s) == TRUE)
        {
            printf("Error: Cannot have duplicate settings!\n");
            hadError = TRUE;
        }
        else
        {
            /*find where the corresponding setting values are*/
            tempM_val= find('M', s);
            tempN_val = find('N', s);
            tempK_val = find('K', s);

            /*assign them to where they belong. Hence, makes order of settingss in file not matter!*/
            s->opt[0].name = 'M' ;
            s->opt[1].name = 'N';
            s->opt[2].name = 'K';
            s->opt[0].val = tempM_val;
            s->opt[1].val = tempN_val;
            s->opt[2].val = tempK_val;

            if(checkValidTiles(s->opt[0].val, s->opt[1].val, s->opt[2].val) == FALSE)/*takes m, n and k*/
            {
                printf("Error: Number of matching tiles cannot be larger than the width and/or height of the board!\n");
                hadError = TRUE;
            }
        }

    }
    else/*If the file was not opened successfully or could not does not exist*/
    {
        perror("Could not open file: \n");/* prints out char* string custom message + system error*/
        hadError = TRUE;
    }

    fclose(file);/*close file stream once finished to avoid any issues*/
    

    return hadError;
}

/**************************
 *FUNCTION: checkSettingsVal 
 *IMPORT: char c, int val
 *EXPORT: int b (BOOLEAN)
 *ASSERTION: b will be either TRUE (1) or FALSE (0)
 *PURPOSE: checks if the settings read were valid
***************************/
int checkSettingVal(char c, int val) 
{
    int b = FALSE;/*b is used to store our defined boolean definition*/
    if(c == 'M' || c == 'm' || c == 'N' || c == 'n' || c == 'K' || c == 'k')/*check correct letter was entered + case insensitive*/
    {
        if(val > 0)/*can't have negative dimensions*/
        {
            b = TRUE;
        }
    }
    return b;   
}


/**************************
 *FUNCTION: findDuplocates 
 *IMPORT: Settings* s
 *EXPORT: int b (BOOLEAN)
 *ASSERTION: b will be either TRUE (1) or FALSE (0)
 *PURPOSE: checks if the settings read contained any duplicates of a specific settings
***************************/
int findDuplicates(Settings* s)
{
    int i;
    int b = FALSE;
    for(i = 1; i < 3; i++)
    {
        /*Checking for duplicates of a specific settings, i.e. two M's or 2K's, etc*/
        if(s->opt[0].name == s->opt[i].name) /*|| s->opt[0].val == s->opt[i].val)*/
        {
            b = TRUE;
        }
    }

    if(s->opt[1].name == s->opt[2].name) /*|| s->opt[1].val == s->opt[2].val)*/
    {
        b = TRUE;
    }
    
    return b;
}
    
/**************************
 *FUNCTION: checkRequiredSettings 
 *IMPORT: int ctr
 *EXPORT: int b (BOOLEAN)
 *ASSERTION: b will be either TRUE (1) or FALSE (0)
 *PURPOSE: If all the settings read were valid, the imported ctr should be 3 to ensure 3 valid settings
***************************/
int checkRequiredSettings(int ctr)
{
    int b = FALSE;

    if(ctr == 3)/*if ctr == 3, that means three values were successfuly read for settings*/
    {
        b = TRUE;        
    } 

    return b;  
}

/**************************
 *FUNCTION: checkValidTiles
 *IMPORT: int m, int n, int k
 *EXPORT: int b (BOOLEAN)
 *ASSERTION: b will be either TRUE (1) or FALSE (0)
 *PURPOSE: Ensures k cannot be bigger than the the bigger value of width(m) or height(n)
***************************/
int checkValidTiles(int m, int n, int k)
{
    int b = TRUE;
    int bigger = n;
        
    /*if statements used to make sure win condition cannot be bigger than the larger value of m or n*/
    if(m > n)
    {
        bigger = m;
    }

    if(k > bigger)
    {
        b = FALSE;
    }

    return b;
}

/**************************
 *FUNCTION: changeSettings 
 *IMPORT: Settings* s
 *EXPORT: void
 *ASSERTION: s will contain new settings
 *PURPOSE: To get new settings from user if they compiled EDITOR mode
***************************/
void changeSettings(Settings* s)
{
    getNewSettings(s);/*function is in UserInterface*/
}

/**************************
 *FUNCTION: displaySettings 
 *IMPORT: Settings* s
 *EXPORT: void
 *ASSERTION: Settings will be displayed
 *PURPOSE: Allow user to read their current settings in the terminal
***************************/
void displaySettings(Settings* s)
{
    int i;

    printf("\nThe current game settings are: \n");
    for(i = 0; i < 3; i++)
    {
        printf("\t\t %c=%d\n", s->opt[i].name, s->opt[i].val);
    }
}

/**************************
 *FUNCTION: find 
 *IMPORT: char c, Settings* s
 *EXPORT: int val
 *ASSERTION: value will be either 0 or the found value
 *PURPOSE: Find the value of a setting in the the array. Used to counter the order of the settings in the file IO
***************************/
int find(char c, Settings* s)
{
    int i;
    int val = 0;
    for(i = 0; i < 3; i++)
    {
        if(s->opt[i].name == c)
        {
            val = s->opt[i].val;
        }
    }
    return val;
} 

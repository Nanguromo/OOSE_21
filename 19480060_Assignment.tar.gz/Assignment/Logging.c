#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Logging.h"
#include "Settings.h"
#include <time.h>
#include "GameLogic.h"

/*************************
 * FUNCTION: makeLogFile 
 * IMPORT: Settings* s, char* logfile
 * EXPORT: none
 * ASSERTION: logfile will have the settings and date in its name
 * PURPOSE: To make a logfile to hold the game logs
 ************************/
void makeLogFile(Settings* s, char* logfile)
{
    /*****************************************************************************
     *      CITATION BELOW for retrieving local time:                            *
     *                                                                           *
     * Techie Delight. 2019. "Print current date and time in C." Techie Delight. *
     *      techiedelight.com/print-current-date-and-time-in-c/                  *
     *                                                                           *
     ****************************************************************************/
    
    time_t now;
    int hours, min, day, month;
    struct tm *local;
    time(&now);
    local = localtime(&now);/*obtain calendar time*/
    hours = local->tm_hour;
    min = local->tm_min;
    day = local->tm_mday;
    month = local->tm_mon + 1;

    sprintf(logfile, "MNK_%d-%d-%d_%d-%d_%d-%d.log", s->opt[0].val, s->opt[1].val, s->opt[2].val, hours, min, day, month);
    
}

/*************************
 * FUNCTION: logSettingsToFile 
 * IMPORT: Settings*s, char* inFile
 * EXPORT: none
 * ASSERTION: will write to the file if not NULL
 * PURPOSE: to write the settings to the logfile
 ************************/
void logSettingsToFile(Settings* s, char* inFile)
{   
    
    FILE* file = fopen(inFile, "w");
    
    if(file != NULL)
    {
        fprintf(file, "SETTINGS:\n");
        fprintf(file, "   M: %d\n", s->opt[0].val);/*M: value*/
        fprintf(file, "   N: %d\n", s->opt[1].val);/*N: value*/
        fprintf(file, "   K: %d\n", s->opt[2].val);/*K: value*/
        fclose(file);
    }
    else
    {
        perror("Error: Could not create logfile!\n"); 
    }
}

/*************************
 * FUNCTION: displayLog 
 * IMPORT: LinkedList* ll, Settings* s
 * EXPORT: none
 * ASSERTION: traverses out linked list's content
 * PURPOSE: To print out all the game moves added to the linked list and the settings to the terminal 
 ************************/
void displayLog(LinkedList* ll, Settings* s)
{
    int ctr = 1;  
    LinkedListNode* node = ll->head;

    printf("\nSETTINGS:\n");
    printf("   M: %d\n", s->opt[0].val);/*M: value*/
    printf("   N: %d\n", s->opt[1].val);/*N: value*/
    printf("   K: %d\n", s->opt[2].val);/*K: value*/
    while(node != NULL)
    {
        if(((Tile*)(node->data))->turn - 1== 0)
        {   
            printf("\nGAME %d:\n", ctr++);
        }
        printf("    Turn: %d\n",((Tile*)(node->data))->turn);
        printf("    Player: %c\n", ((Tile*)(node->data))->type);
        printf("    Location: %d,%d\n",((Tile*)(node->data))->move.x, ((Tile*)(node->data))->move.y); 
        printf("\n");
        node = node->next;
    }
}

/*************************
 * FUNCTION: writeLogToFIle 
 * IMPORT: LinkedList* ll, Settings* s, char* fileName
 * EXPORT: none
 * ASSERTION: 
 * PURPOSE: wrapper function for main to call to hide implementation
 ************************/
void writeLogToFile(LinkedList* ll, Settings* s, char* fileName)
{
    
    logSettingsToFile(s, fileName);

    logTurnsToFile(ll, s, fileName);

}

/*************************
 * FUNCTION: logTurnsToFile
 * IMPORT: LinkedList* ll, Settings* s, char* fileName
 * EXPORT: none
 * ASSERTION: Appends to file if not NULL
 * PURPOSE: To log the recorded game turns done by the player to a file
 ************************/
void logTurnsToFile(LinkedList* ll, Settings* s, char* fileName)
{
    int ctr = 1;
    FILE* log = fopen(fileName, "a");
    LinkedListNode* node = ll->head;

    if(log != NULL)
    {
        while(node != NULL)
        {
            if( ((Tile*)(node->data))->turn - 1 == 0)
            {
                fprintf(log, "\nGAME %d:\n", ctr++);
                fprintf(log, "    Turn: %d\n", ((Tile*)(node->data))->turn);
                fprintf(log, "    Player: %c\n", ((Tile*)(node->data))->type);
                fprintf(log, "    Location: %d,%d\n", ((Tile*)(node->data))->move.x, ((Tile*)(node->data))->move.y);
                fprintf(log, "\n");
            }
            else
            {
                fprintf(log, "    Turn: %d\n", ((Tile*)(node->data))->turn);
                fprintf(log, "    Player: %c\n", ((Tile*)(node->data))->type);
                fprintf(log, "    Location: %d,%d\n", ((Tile*)(node->data))->move.x, ((Tile*)(node->data))->move.y);
                fprintf(log, "\n");
            }
            node = node->next;
        }
        fclose(log);
    }   
    else
    {
        perror("Error: Could not open file to log turn!\n");
    }
}

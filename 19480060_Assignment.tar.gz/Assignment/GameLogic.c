#include "Settings.h"
#include <stdio.h>
#include "GameLogic.h"


/*************************
 *FUNCTION: checkBounds
 *IMPORT: int m, int n, int x, int y
 *EXPORT: int withinBounds (BOOLEAN)
 *ASSERTION: withinBounds will be either TRUE (1) or FALSE(0)
 *PURPOSE: Ensures inputted coordinates is not greater than dimensions of board
 ************************/
int checkBounds(int m, int n, int x, int y)
{
    int withinBounds = TRUE;

    if(x >= m || y >= n)
    {
        withinBounds = FALSE;
    }

    /*printf("%d %d %d %d",m,n,x,y);*/
    return withinBounds;
}

/*************************
 *FUNCTION: checkFreeTile
 *IMPORT: int x, int y, Tile** grid
 *EXPORT: int freeTile (BOOLEAN)
 *ASSERTION: freeTile will be either TRUE (1) or FALSE(0)
 *PURPOSE: Ensures the selected tile is NOT occupied
 ************************/
int checkFreeTile(int x, int y, Tile** grid)
{
    int freeTile = FALSE;
    if((*(*(grid+y)+x)).isEmpty == TRUE)
    {
        freeTile = TRUE;
    }
    return freeTile;
}

/*************************
 *FUNCTION: checkWinningMove
 *IMPORT: Tile** grid, int originalX, int originalY, int m, int n, int k
 *EXPORT:int winningMove (BOOLEAN)
 *ASSERTION: check
 *PURPOSE:
 ************************/
int checkWinningMove(Tile** grid, int originalX, int originalY, int m, int n, int k)
{
    int ctr = 1;
    int winningMove = FALSE;
    int x1 = originalX;
    int x2 = originalX;
    int y1 = originalY;
    int y2 = originalY;
    /*check vertical*/
    /*printf("\nVERTICAL\n");*/
    while(y1 > 0 || y2 < n-1)
    {
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
        /*check up*/
        if(y1 > 0)
        {
            if(grid[y1][x1].type == grid[y1-1][x1].type)
            {
                ctr++;
            }
        }
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
        /*check down*/
        if(y2 < n-1)
        {
            if(grid[y2][x2].type == grid[y2+1][x2].type)
            {    
                ctr++;
            }
        }
        if(ctr == k)
        {
            winningMove = TRUE;       
        }
        y1--;
        y2++;
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
    }
    
    /*check horizontal*/
    /*printf("\nHORIZONTAL\n");*/
    ctr = 1;
    x1 = originalX;
    x2 = originalX;
    y1 = originalY;
    y2 = originalY;
    while(x1 > 0 || x2 < m-1)    
    {
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
        /*check left*/  
        if(x1 > 0)
        {
            /*printf("\n%c %c\n",grid[y2][x2].type, grid[y2][x2-1].type);*/
            if(grid[y1][x1].type == grid[y1][x1-1].type)
            {
                ctr++;
            }
            /*printf("\nentersx1\n");*/
        }
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
        /*check right*/
        if(x2 < m-1)
        {
            /*printf("\n%c %c\n",grid[y2][x2].type, grid[y2][x2+1].type);*/
            if(grid[y2][x2].type == grid[y2][x2+1].type)
            {
                ctr++;
            }
            /*printf("\nentersx2\n");*/
        }
        if(ctr == k)
        {
            winningMove = TRUE;       
        }
        x1--;
        x2++;
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
    }

    /*check up-right and down-left diagonal*/
    ctr = 1;
    x1  = originalX;
    x2  = originalX;
    y1 = originalY;
    y2  = originalY;
    /*printf("\nDIAGONAL UPRIGHT\n");*/
    while( (x1 < m-1 && y1 > 0) || (x2 > 0 && y2 < n-1) )   
    {
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
        if(x1 < m-1 && y1 > 0)
        {
            if(grid[y1][x1].type == grid[y1-1][x1+1].type)
            {
                ctr++;
            }
        }
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
        if(x2 > 0 && y2 < n-1)
        {
            if(grid[y2][x2].type == grid[y2+1][x2-1].type)
            {
                ctr++;
            }
        }
        if(ctr == k)
        {
            winningMove = TRUE;       
        }
        y1--;
        x1++;
        y2++;
        x2--;
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
    }

    /*check up-left and down-right diagonal*/
    ctr = 1;
    x1  = originalX;
    x2  = originalX;
    y1 = originalY;
    y2  = originalY;
    /*printf("\nDIAGONAL UPLEFT\n");*/
    while( (x1 > 0 && y1 > 0) || (x2 < m-1 && y2 < n-1) )   
    {
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
        if(x1 > 0 && y1 >0)
        {
            if(grid[y1][x1].type == grid[y1-1][x1-1].type)
            {
                ctr++;
            }
        }
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
        if( x2< m-1 && y2 < n-1)
        {
            if(grid[y2][x2].type == grid[y2+1][x2+1].type)
            {
                ctr++;
            }
        }
        if(ctr == k)
        {
            winningMove = TRUE;       
        }
        y1--;
        x1--;
        y2++;
        x2++;
        /*printf("ctr = %d, k = %d\n", ctr, k);*/
    }

    return winningMove;
}

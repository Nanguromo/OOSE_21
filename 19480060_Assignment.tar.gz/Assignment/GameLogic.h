#include "Settings.h"
#ifndef GAME_LOGIC
#define GAME_LOGIC
    typedef struct{
        int x;
        int y;
    }Move;

    typedef struct{
        char type;
        int turn;
        int isEmpty;/*boolean*/
        Move move;
    }Tile;

    int checkBounds(int m, int n, int x, int y);

    int checkFreeTile(int x, int y, Tile** grid);

    int checkWinningMove(Tile** grid, int x, int y, int m, int n, int k);
#endif

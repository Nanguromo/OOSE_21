#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Settings.h"
#include "UserInterface.h"
#include "LinkedList.h"
#include "Logging.h"

int main(int argc, char* argv[])
{
    /*Declarations here*/
    Settings* s = (Settings*)malloc(sizeof(Settings));/*Remember to free this as it was malloc'd!*/
    int hadError, option, gameCtr;
    char logFileName[50];
    LinkedList* ll = createLinkedList();
    FUNC_PTR func = &freeTile;
    gameCtr = 0;
    if(argc == 2)
    {
        hadError = readSettings(s, argv[1]);/*argv[1]  is the command line parameter for the file name*/
        
        if(hadError == FALSE)/*If the game settings were hadError; continue on with the program or else exit*/
        {
            do
            {
            displayOptions();
            option = getOption();
            
            if(option != 0) /*Ensure a hadError input was entered, or else exit!*/
            {
                switch(option)
                {
                    case 1:
                        gameCtr++;
                        drawEmptyBoard(s->opt[0].val, s->opt[1].val);
                        drawGame(s->opt[0].val, s->opt[1].val, s->opt[2].val, gameCtr, ll, logFileName);
                        
                        break;
                    case 2:
                        displaySettings(s);
                        break;
                    case 3:
                        displayLog(ll, s);
                        break;
                    #ifndef SECRET
                    case 4:
                        makeLogFile(s, logFileName);
                        logSettingsToFile(s, logFileName);        
                        writeLogToFile(ll, s, logFileName);
                        break;
                    #endif

                    #ifdef EDITOR
                    #ifndef SECRET
                    case 5:
                        changeSettings(s);
                        break;
                    #else
                    case 4:
                        changeSettings(s);
                        break;
                    #endif
                        /*changeSettings(s);
                        break;*/
                    #endif
                    default:
                        printf("\nGoodbye! Thanks for playing.\n");
                        break;
                    }
                } 
                printf("\n");
            #if defined(EDITOR) && defined(SECRET)
            }while(option !=5);
            #elif defined(EDITOR)
            }while(option != 6);
            #elif defined(SECRET)
            }while(option != 4);
            #else
            }while(option !=5);
            #endif 
            
        }
    }
    else
    {
        printf("Error: To run game you must have one command line parameter; the settings file!\n");
    }
    freeLinkedList(ll, func); 
    free(s);  
    s = NULL; 
    return 0;
}

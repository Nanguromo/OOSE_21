#include <stdio.h>
#include "Settings.h"
#include "LinkedList.h"

#ifndef LOGGING
#define LOGGING
    void makeLogFile(Settings* s, char* logfile);
    
    void logSettingsToFile(Settings* s, char* inFile);
    
    void writeLogToFile(LinkedList* ll, Settings* s, char* logFileName);
    
    void displayLog(LinkedList* ll, Settings* s);

    void logTurnsToFile(LinkedList* ll, Settings* s, char* fileName);
#endif


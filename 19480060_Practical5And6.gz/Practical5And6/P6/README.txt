SecuritySystem was refactored to adhere to Dependency Injection principles.

Main is used to inject the dependencies into SecuritySystem;
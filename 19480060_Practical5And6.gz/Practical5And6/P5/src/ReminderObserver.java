public interface ReminderObserver
{
    public void updateReminder();
}